/* 
 * File:   Card.cpp
 * Author: Owner
 *
 * Created on May 27, 2015, 11:51 AM
 */

#include <cstdlib>
#include "Card.h"
using namespace std;

Card::Card(){
    color = "NC";
    number = -3;
    action = -5;
    wild = false;
    strAction = "NSA"; 
}